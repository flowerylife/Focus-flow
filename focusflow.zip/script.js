let time = 1500;
let interval = null;
let sessions = 0;

function updateDisplay() {
  let minutes = Math.floor(time / 60);
  let seconds = time % 60;

  document.getElementById("time").innerText =
    `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
}

function startTimer() {
  if (interval) return;

  interval = setInterval(() => {
    time--;

    updateDisplay();

    if (time <= 0) {
      clearInterval(interval);
      interval = null;

      sessions++;
      document.getElementById("sessionCount").innerText =
        "Sessions completed: " + sessions;

      alert("Great job! Focus session complete 🔥");
      resetTimer();
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(interval);
  interval = null;
  time = 1500;
  updateDisplay();
}

function scrollToApp() {
  document.getElementById("app").scrollIntoView({ behavior: "smooth" });
}

updateDisplay();
